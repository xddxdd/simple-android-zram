# Simple Android ZRAM

A simple Magisk module that creates a 4GB ZRAM swap on Android devices.
